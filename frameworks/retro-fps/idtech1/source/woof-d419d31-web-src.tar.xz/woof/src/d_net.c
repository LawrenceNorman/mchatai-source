//
// Copyright(C) 1993-1996 Id Software, Inc.
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//	DOOM Network game communication and protocol,
//	all OS independend parts.
//

#include "d_loop.h"
#include "d_main.h"
#include "d_player.h"
#include "d_ticcmd.h"
#include "doomdef.h"
#include "doomstat.h"
#include "doomtype.h"
#include "g_game.h"
#include "i_printf.h"
#include "m_argv.h"
#include "m_misc.h"
#include "nw_defs.h"
#include "p_mobj.h"
#include "tables.h"

ticcmd_t *netcmds;

// Called when a player leaves the game

static void PlayerQuitGame(player_t *player)
{
    static char exitmsg[80];
    unsigned int player_num;

    player_num = player - players;

    // Do this the same way as Vanilla Doom does, to allow dehacked
    // replacements of this message

    M_StringCopy(exitmsg, "Player 1 left the game",
                 sizeof(exitmsg));

    exitmsg[7] += player_num;

    playeringame[player_num] = false;
    displaymsg("%s", exitmsg);
    // [crispy] don't interpolate players who left the game
    player->mo->interp = false;

    // TODO: check if it is sensible to do this:

    if (demorecording)
    {
        G_CheckDemoStatus ();
    }
}

void D_DoAdvanceDemo(void);

void RunTic(ticcmd_t *cmds, boolean *ingame)
{
    unsigned int i;

    // Check for player quits.

    for (i = 0; i < MAXPLAYERS; ++i)
    {
        if (!demoplayback && playeringame[i] && !ingame[i])
        {
            PlayerQuitGame(&players[i]);
        }
    }

    netcmds = cmds;

    // check that there are players in the game.  if not, we cannot
    // run a tic.

    if (advancedemo)
        D_DoAdvanceDemo ();

    G_Ticker ();
}

// Load game settings from the specified structure and
// set global variables.

static void LoadGameSettings(nw_gamesettings_t *settings)
{
    unsigned int i;

    if (lowres_turn)
    {
        I_Printf(VB_WARNING, "NOTE: Turning resolution is reduced; this is probably "
                "because there is a client recording a Vanilla demo.");
    }

    for (i = 0; i < MAXPLAYERS; ++i)
    {
        playeringame[i] = i < settings->num_players;
    }

    demo_version = settings->demo_version;

    if (demo_version == 0)
    {
        demo_version = DV_VANILLA;
    }

    if (demo_version == DV_VANILLA)
    {
        compatibility = true;
    }

    if (mbf21)
    {
        G_ReadOptionsMBF21(settings->options);
    }
    else
    {
        G_ReadOptions(settings->options);
    }

    deathmatch = settings->deathmatch;
    startepisode = settings->episode;
    startmap = settings->map;
    startskill = settings->skill;
    startloadgame = settings->loadgame;
    lowres_turn = settings->lowres_turn;
    nomonsters = settings->nomonsters;
    fastparm = settings->fast_monsters;
    respawnparm = settings->respawn_monsters;
    timelimit = settings->timelimit;
    consoleplayer = settings->consoleplayer;
}

// Save the game settings from global variables to the specified
// game settings structure.

static void SaveGameSettings(nw_gamesettings_t *settings)
{
    // Fill in game settings structure with appropriate parameters
    // for the new game

    settings->deathmatch = deathmatch;
    settings->episode = startepisode;
    settings->map = startmap;
    settings->skill = startskill;
    settings->loadgame = startloadgame;
    settings->gameversion = gameversion;
    settings->nomonsters = nomonsters;
    settings->fast_monsters = fastparm;
    settings->respawn_monsters = respawnparm;
    settings->timelimit = timelimit;

    //!
    // @category demo
    //
    // Record a high resolution "Doom 1.91" demo.
    //

    longtics = (demo_compatibility && M_ParmExists("-longtics")) || mbf21;

    settings->lowres_turn = ((M_ParmExists("-record") && !longtics) ||

    //!
    // @category demo
    // @help
    //
    // Play with low turning resolution to emulate demo recording.
    //

    M_ParmExists("-shorttics") || shorttics);

    settings->demo_version = demo_version;
    G_WriteOptions(settings->options);
}

static void InitConnectData(nw_connect_data_t *connect_data)
{
    connect_data->max_players = MAXPLAYERS;
    connect_data->drone = false;

    //!
    // @category net
    //
    // Run as the left screen in three screen mode.
    //

    if (M_CheckParm("-left") > 0)
    {
        viewangleoffset = ANG90;
        connect_data->drone = true;
    }

    //!
    // @category net
    //
    // Run as the right screen in three screen mode.
    //

    if (M_CheckParm("-right") > 0)
    {
        viewangleoffset = ANG270;
        connect_data->drone = true;
    }

    //
    // Connect data
    //

    // Game type fields:

    connect_data->gamemode = gamemode;
    connect_data->gamemission = gamemission;

    longtics = (demo_compatibility && M_ParmExists("-longtics")) || mbf21;

    // Are we recording a demo? Possibly set lowres turn mode

    connect_data->lowres_turn = ((M_ParmExists("-record") && !longtics) ||
                                 M_ParmExists("-shorttics") || shorttics);

    // Read checksums of our WAD directory and dehacked information

    //W_Checksum(connect_data->wad_sha1sum);
    //DEH_Checksum(connect_data->deh_sha1sum);

    // Are we playing with the Freedoom IWAD?

    //connect_data->is_freedoom = W_CheckNumForName("FREEDOOM") >= 0;
}

void D_ConnectNetGame(void)
{
    nw_connect_data_t connect_data;

    InitConnectData(&connect_data);
    netgame = D_InitNetGame(&connect_data);

    //!
    // @category net
    //
    // Start the game playing as though in a netgame with a single
    // player.  This can also be used to play back single player netgame
    // demos.
    //

    if (M_CheckParm("-solo-net") > 0)
    {
        netgame = true;
        solonet = true;
    }
}

//
// D_CheckNetGame
// Works out player numbers among the net participants
//
void D_CheckNetGame (void)
{
    nw_gamesettings_t settings;

    if (netgame)
    {
        autostart = true;
    }

    SaveGameSettings(&settings);
    D_StartNetGame(&settings, NULL);
    LoadGameSettings(&settings);

    I_Printf(VB_INFO, " startskill %i  deathmatch: %i  startmap: %i  startepisode: %i",
               startskill, deathmatch, startmap, startepisode);

    I_Printf(VB_INFO, " player %i of %i (%i nodes)",
               consoleplayer+1, settings.num_players, settings.num_players);
}

