//
// Copyright(C) 2005-2014 Simon Howard
// Copyright(C) 2014 Fabian Greffrath
// Copyright(C) 2021 Roman Fomin
// Copyright(C) 2025 Guilherme Miranda
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
//
// Parses [CODEPTR] sections in BEX files
//

#include <stdio.h>
#include <string.h>

#include "deh_io.h"
#include "deh_main.h"
#include "deh_mapping.h"
#include "doomtype.h"
#include "i_system.h"
#include "info.h"
#include "m_fixed.h"
#include "p_action.h"

typedef struct
{
    const char *mnemonic;
    const actionf_t pointer;
    const int argcount;           // [XA] number of mbf21 args this action uses, if any
    const int args[MAXSTATEARGS]; // default values for mbf21 args
} bex_codepointer_t;

const bex_codepointer_t bex_pointer_null = {"(NULL)", {NULL}};

static const bex_codepointer_t bex_pointer_table[] =
{
    {"Light0",              {.p3 = A_Light0}                 },
    {"WeaponReady",         {.p3 = A_WeaponReady}            },
    {"Lower",               {.p3 = A_Lower}                  },
    {"Raise",               {.p3 = A_Raise}                  },
    {"Punch",               {.p3 = A_Punch}                  },
    {"ReFire",              {.p3 = A_ReFire}                 },
    {"FirePistol",          {.p3 = A_FirePistol}             },
    {"Light1",              {.p3 = A_Light1}                 },
    {"FireShotgun",         {.p3 = A_FireShotgun}            },
    {"Light2",              {.p3 = A_Light2}                 },
    {"FireShotgun2",        {.p3 = A_FireShotgun2}           },
    {"CheckReload",         {.p3 = A_CheckReload}            },
    {"OpenShotgun2",        {.p3 = A_OpenShotgun2}           },
    {"LoadShotgun2",        {.p3 = A_LoadShotgun2}           },
    {"CloseShotgun2",       {.p3 = A_CloseShotgun2}          },
    {"FireCGun",            {.p3 = A_FireCGun}               },
    {"GunFlash",            {.p3 = A_GunFlash}               },
    {"FireMissile",         {.p3 = A_FireMissile}            },
    {"Saw",                 {.p3 = A_Saw}                    },
    {"FirePlasma",          {.p3 = A_FirePlasma}             },
    {"BFGsound",            {.p3 = A_BFGsound}               },
    {"FireBFG",             {.p3 = A_FireBFG}                },
    {"BFGSpray",            {.p3 = A_BFGSpray}               },
    {"Explode",             {.p3 = A_Explode}                },
    {"Pain",                {.p3 = A_Pain}                   },
    {"PlayerScream",        {.p3 = A_PlayerScream}           },
    {"Fall",                {.p3 = A_Fall}                   },
    {"XScream",             {.p3 = A_XScream}                },
    {"Look",                {.p3 = A_Look}                   },
    {"Chase",               {.p3 = A_Chase}                  },
    {"FaceTarget",          {.p3 = A_FaceTarget}             },
    {"PosAttack",           {.p3 = A_PosAttack}              },
    {"Scream",              {.p3 = A_Scream}                 },
    {"SPosAttack",          {.p3 = A_SPosAttack}             },
    {"VileChase",           {.p3 = A_VileChase}              },
    {"VileStart",           {.p3 = A_VileStart}              },
    {"VileTarget",          {.p3 = A_VileTarget}             },
    {"VileAttack",          {.p3 = A_VileAttack}             },
    {"StartFire",           {.p3 = A_StartFire}              },
    {"Fire",                {.p3 = A_Fire}                   },
    {"FireCrackle",         {.p3 = A_FireCrackle}            },
    {"Tracer",              {.p3 = A_Tracer}                 },
    {"SkelWhoosh",          {.p3 = A_SkelWhoosh}             },
    {"SkelFist",            {.p3 = A_SkelFist}               },
    {"SkelMissile",         {.p3 = A_SkelMissile}            },
    {"FatRaise",            {.p3 = A_FatRaise}               },
    {"FatAttack1",          {.p3 = A_FatAttack1}             },
    {"FatAttack2",          {.p3 = A_FatAttack2}             },
    {"FatAttack3",          {.p3 = A_FatAttack3}             },
    {"BossDeath",           {.p3 = A_BossDeath}              },
    {"CPosAttack",          {.p3 = A_CPosAttack}             },
    {"CPosRefire",          {.p3 = A_CPosRefire}             },
    {"TroopAttack",         {.p3 = A_TroopAttack}            },
    {"SargAttack",          {.p3 = A_SargAttack}             },
    {"HeadAttack",          {.p3 = A_HeadAttack}             },
    {"BruisAttack",         {.p3 = A_BruisAttack}            },
    {"SkullAttack",         {.p3 = A_SkullAttack}            },
    {"Metal",               {.p3 = A_Metal}                  },
    {"SpidRefire",          {.p3 = A_SpidRefire}             },
    {"BabyMetal",           {.p3 = A_BabyMetal}              },
    {"BspiAttack",          {.p3 = A_BspiAttack}             },
    {"Hoof",                {.p3 = A_Hoof}                   },
    {"CyberAttack",         {.p3 = A_CyberAttack}            },
    {"PainAttack",          {.p3 = A_PainAttack}             },
    {"PainDie",             {.p3 = A_PainDie}                },
    {"KeenDie",             {.p3 = A_KeenDie}                },
    {"BrainPain",           {.p3 = A_BrainPain}              },
    {"BrainScream",         {.p3 = A_BrainScream}            },
    {"BrainDie",            {.p3 = A_BrainDie}               },
    {"BrainAwake",          {.p3 = A_BrainAwake}             },
    {"BrainSpit",           {.p3 = A_BrainSpit}              },
    {"SpawnSound",          {.p3 = A_SpawnSound}             },
    {"SpawnFly",            {.p3 = A_SpawnFly}               },
    {"BrainExplode",        {.p3 = A_BrainExplode}           },
    // MBF
    {"Detonate",            {.p3 = A_Detonate}               },
    {"Mushroom",            {.p3 = A_Mushroom}               },
    {"Die",                 {.p3 = A_Die}                    },
    {"Spawn",               {.p3 = A_Spawn}                  },
    {"Turn",                {.p3 = A_Turn}                   },
    {"Face",                {.p3 = A_Face}                   },
    {"Scratch",             {.p3 = A_Scratch}                },
    {"PlaySound",           {.p3 = A_PlaySound}              },
    {"RandomJump",          {.p3 = A_RandomJump}             },
    {"LineEffect",          {.p3 = A_LineEffect}             },
    {"FireOldBFG",          {.p3 = A_FireOldBFG}             },
    {"BetaSkullAttack",     {.p3 = A_BetaSkullAttack}        },
    {"Stop",                {.p3 = A_Stop}                   },
    // MBF21
    {"SpawnObject",         {.p3 = A_SpawnObject},         8 },
    {"MonsterProjectile",   {.p3 = A_MonsterProjectile},   5 },
    {"MonsterBulletAttack", {.p3 = A_MonsterBulletAttack}, 5, { 0, 0, 1, 3, 5 } },
    {"MonsterMeleeAttack",  {.p3 = A_MonsterMeleeAttack},  4, { 3, 8, 0, 0 } },
    {"RadiusDamage",        {.p3 = A_RadiusDamage},        2 },
    {"NoiseAlert",          {.p3 = A_NoiseAlert},          0 },
    {"HealChase",           {.p3 = A_HealChase},           2 },
    {"SeekTracer",          {.p3 = A_SeekTracer},          2 },
    {"FindTracer",          {.p3 = A_FindTracer},          2, { 0, 10 } },
    {"ClearTracer",         {.p3 = A_ClearTracer},         0 },
    {"JumpIfHealthBelow",   {.p3 = A_JumpIfHealthBelow},   2 },
    {"JumpIfTargetInSight", {.p3 = A_JumpIfTargetInSight}, 2 },
    {"JumpIfTargetCloser",  {.p3 = A_JumpIfTargetCloser},  2 },
    {"JumpIfTracerInSight", {.p3 = A_JumpIfTracerInSight}, 2 },
    {"JumpIfTracerCloser",  {.p3 = A_JumpIfTracerCloser},  2 },
    {"JumpIfFlagsSet",      {.p3 = A_JumpIfFlagsSet},      3 },
    {"AddFlags",            {.p3 = A_AddFlags},            2 },
    {"RemoveFlags",         {.p3 = A_RemoveFlags},         2 },
    {"WeaponProjectile",    {.p3 = A_WeaponProjectile},    5 },
    {"WeaponBulletAttack",  {.p3 = A_WeaponBulletAttack},  5, { 0, 0, 1, 5, 3 } },
    {"WeaponMeleeAttack",   {.p3 = A_WeaponMeleeAttack},   5, { 2, 10, 1 * FRACUNIT, 0, 0 } },
    {"WeaponSound",         {.p3 = A_WeaponSound},         2 },
    {"WeaponAlert",         {.p3 = A_WeaponAlert},         0 },
    {"WeaponJump",          {.p3 = A_WeaponJump},          2 },
    {"ConsumeAmmo",         {.p3 = A_ConsumeAmmo},         1 },
    {"CheckAmmo",           {.p3 = A_CheckAmmo},           2 },
    {"RefireTo",            {.p3 = A_RefireTo},            2 },
    {"GunFlashTo",          {.p3 = A_GunFlashTo},          2 },
    {"NULL",                {NULL}                           },
};

typedef enum
{
    arg_1,
    arg_1_inc,
    arg_2,
    arg_3,
    arg_4,
    arg_misc1,
    arg_misc1_inc
} arg_type_t;

typedef struct
{
    const actionf_t pointer;
    arg_type_t argtype;
} translate_args_t;

static translate_args_t translate_states[] = {
    { {.p3 = A_RandomJump },          arg_misc1 },
    { {.p3 = A_HealChase },           arg_1 },
    { {.p3 = A_JumpIfHealthBelow },   arg_1 },
    { {.p3 = A_JumpIfTargetInSight }, arg_1 },
    { {.p3 = A_JumpIfTargetCloser },  arg_1 },
    { {.p3 = A_JumpIfTracerInSight }, arg_1 },
    { {.p3 = A_JumpIfTracerCloser },  arg_1 },
    { {.p3 = A_JumpIfFlagsSet },      arg_1 },
    { {.p3 = A_WeaponJump },          arg_1 },
    { {.p3 = A_CheckAmmo },           arg_1 },
    { {.p3 = A_RefireTo },            arg_1 },
    { {.p3 = A_GunFlashTo },          arg_1 },
};

static translate_args_t translate_things[] = {
    { {.p3 = A_Spawn},              arg_misc1_inc },
    { {.p3 = A_SpawnObject},        arg_1_inc },
    { {.p3 = A_MonsterProjectile},  arg_1_inc },
    { {.p3 = A_WeaponProjectile},   arg_1_inc },
};

static translate_args_t translate_sounds[] = {
    { {.p3 = A_PlaySound},          arg_misc1},
    { {.p3 = A_MonsterMeleeAttack}, arg_3 },
    { {.p3 = A_HealChase},          arg_2 },
    { {.p3 = A_WeaponMeleeAttack},  arg_4 },
    { {.p3 = A_WeaponSound},        arg_1 },
};

static void TranslateArgs(state_t *state,
                          translate_args_t *table, int size,
                          deh_translate_t translate)
{
    for (int i = 0; i < size; ++i)
    {
        if (state->action.v == table[i].pointer.v)
        {
            switch (table[i].argtype)
            {
                case arg_1:
                    state->args[0] = translate(state->args[0]);
                    break;
                case arg_1_inc:
                    state->args[0] = translate(state->args[0] - 1) + 1;
                    break;
                case arg_2:
                    state->args[1] = translate(state->args[1]);
                    break;
                case arg_3:
                    state->args[2] = translate(state->args[2]);
                    break;
                case arg_4:
                    state->args[3] = translate(state->args[3]);
                    break;
                case arg_misc1:
                    state->misc1 = translate(state->misc1);
                    break;
                case arg_misc1_inc:
                    state->misc1 = translate(state->misc1 - 1) + 1;
                    break;
            }
            return;
        }
    }
}

void DEH_ValidateStateArgs(void)
{
    const bex_codepointer_t *bex_pointer_match;

    for (int i = 0; i < num_states; i++)
    {
        state_t *state = &states[i];

        bex_pointer_match = &bex_pointer_null;

        for (int j = 0; bex_pointer_table[j].pointer.v != NULL; ++j)
        {
            if (state->action.v == bex_pointer_table[j].pointer.v)
            {
                bex_pointer_match = &bex_pointer_table[j];
                break;
            }
        }

        // ensure states don't use more mbf21 args than their
        // action pointer expects, for future-proofing's sake
        int k;
        for (k = MAXSTATEARGS - 1; k >= bex_pointer_match->argcount; k--)
        {
            if (state->args[k] != 0)
            {
                I_Error("Action %s on state %d expects no more than %d nonzero "
                        "args (%d found). Check your dehacked.",
                        bex_pointer_match->mnemonic, i,
                        bex_pointer_match->argcount, k + 1);
            }
        }

        byte defined_args = DEH_GetDefinedCodepointerArgs(i);

        // replace unset fields with default values
        for (; k >= 0; k--)
        {
            if (!(defined_args & (1 << k)))
            {
                state->args[k] = bex_pointer_match->args[k];
            }
        }

        TranslateArgs(state, translate_states, arrlen(translate_states),
                      DSDH_StateTranslate);
        TranslateArgs(state, translate_things, arrlen(translate_things),
                      DSDH_ThingTranslate);
        TranslateArgs(state, translate_sounds, arrlen(translate_sounds),
                      DSDH_SoundTranslate);
    }
}

boolean DEH_CheckSafeState(statenum_t state)
{
    int count = 0;

    for (statenum_t s = state; s != S_NULL; s = states[s].nextstate)
    {
        // [FG] recursive/nested states
        if (count++ >= 100)
        {
            return false;
        }

        // [crispy] a state with -1 tics never changes
        if (states[s].tics == -1)
        {
            break;
        }

        if (states[s].action.p3)
        {
            // [FG] A_Light*() considered harmless
            if (states[s].action.p3 == (actionf_p3)A_Light0
                || states[s].action.p3 == (actionf_p3)A_Light1
                || states[s].action.p3 == (actionf_p3)A_Light2)
            {
                continue;
            }
            else
            {
                return false;
            }
        }
    }

    return true;
}

static int DEH_BEXPointerStart(deh_context_t *context, char *line)
{
    char s[10];

    if (sscanf(line, "%9s", s) == 0 || strcmp("[CODEPTR]", s))
    {
        DEH_Warning(context, "Parse error on section start");
    }

    return 0;
}

static void DEH_BEXPointerParseLine(deh_context_t *context, char *line, int tag)
{
    // parse "FRAME nn = mnemonic", where
    // variable_name = "FRAME nn" and value = "mnemonic"
    char *variable_name, *value;
    if (!DEH_ParseAssignment(line, &variable_name, &value))
    {
        DEH_Warning(context, "Failed to parse assignment: %s", line);
        return;
    }

    // parse "FRAME nn", where frame_number = "nn"
    int frame_number = -1;
    char frame_str[6];
    if (sscanf(variable_name, "%5s %32d", frame_str, &frame_number) != 2 || strcasecmp(frame_str, "FRAME"))
    {
        DEH_Warning(context, "Failed to parse assignment: %s", variable_name);
        return;
    }

    if (frame_number < 0)
    {
        DEH_Warning(context, "Invalid frame number: %i", frame_number);
        return;
    }

    // DSDHacked
    frame_number = DSDH_StateTranslate(frame_number);

    state_t *state = &states[frame_number];

    for (int i = 0; i < arrlen(bex_pointer_table); i++)
    {
        if (!strcasecmp(bex_pointer_table[i].mnemonic, value))
        {
            state->action = bex_pointer_table[i].pointer;
            return;
        }
    }

    DEH_Warning(context, "Invalid mnemonic '%s'", value);
}

deh_section_t deh_section_bex_codepointers =
{
    "[CODEPTR]",
    NULL,
    DEH_BEXPointerStart,
    DEH_BEXPointerParseLine,
    NULL,
    NULL,
};
