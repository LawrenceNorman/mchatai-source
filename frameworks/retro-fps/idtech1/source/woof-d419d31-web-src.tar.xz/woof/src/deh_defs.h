//
// Copyright(C) 2005-2014 Simon Howard
// Copyright(C) 2025 Guilherme Miranda
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
//
// Definitions for use in the dehacked code
//

#ifndef DEH_DEFS_H
#define DEH_DEFS_H

#include "sha1.h"

typedef struct deh_context_s deh_context_t;
typedef struct deh_section_s deh_section_t;
typedef void (*deh_section_init_t)(void);
typedef int (*deh_section_start_t)(deh_context_t *context, char *line);
typedef void (*deh_section_end_t)(deh_context_t *context, int tag);
typedef void (*deh_line_parser_t)(deh_context_t *context, char *line, int tag);
typedef void (*deh_sha1_hash_t)(sha1_context_t *context);

struct deh_section_s
{
    const char *name;

    // Called on startup to initialize code
    deh_section_init_t init;

    // This is called when a new section is started.  The pointer
    // returned is used as a tag for the following calls.
    deh_section_start_t start;

    // This is called for each line in the section
    deh_line_parser_t line_parser;

    // This is called at the end of the section for any cleanup
    deh_section_end_t end;

    // Called when generating an SHA1 sum of the dehacked state
    deh_sha1_hash_t sha1_hash;
};

extern deh_section_t deh_section_ammo;
extern deh_section_t deh_section_cheat;
extern deh_section_t deh_section_frame;
extern deh_section_t deh_section_misc;
extern deh_section_t deh_section_pointer;
extern deh_section_t deh_section_sound;
extern deh_section_t deh_section_text;
extern deh_section_t deh_section_thing;
extern deh_section_t deh_section_weapon;

extern deh_section_t deh_section_bex_codepointers;
extern deh_section_t deh_section_bex_includes;
extern deh_section_t deh_section_bex_partimes;
extern deh_section_t deh_section_bex_strings;

extern deh_section_t deh_section_bex_helper;
extern deh_section_t deh_section_bex_music;
extern deh_section_t deh_section_bex_sounds;
extern deh_section_t deh_section_bex_sprites;

#endif /* #ifndef DEH_DEFS_H */
