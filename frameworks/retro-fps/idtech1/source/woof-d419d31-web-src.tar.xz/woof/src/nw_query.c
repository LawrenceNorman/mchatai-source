//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//     Querying servers to find their current status.
//

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "doomdef.h"
#include "i_printf.h"
#include "i_system.h"
#include "i_timer.h"
#include "nw_defs.h"
#include "nw_io.h"
#include "nw_packet.h"
#include "nw_query.h"
#include "nw_sdl.h"
#include "nw_structrw.h"

// DNS address of the Internet master server.

#define MASTER_SERVER_ADDRESS "master.chocolate-doom.org:2342"

// Time to wait for a response before declaring a timeout.

#define QUERY_TIMEOUT_SECS    2

// Time to wait for secure demo signatures before declaring a timeout.

// #define SIGNATURE_TIMEOUT_SECS 5

// Number of query attempts to make before giving up on a server.

#define QUERY_MAX_ATTEMPTS    3

typedef enum
{
    QUERY_TARGET_SERVER,   // Normal server target.
    QUERY_TARGET_MASTER,   // The master server.
    QUERY_TARGET_BROADCAST // Send a broadcast query
} query_target_type_t;

typedef enum
{
    QUERY_TARGET_QUEUED,    // Query not yet sent
    QUERY_TARGET_QUERIED,   // Query sent, waiting response
    QUERY_TARGET_RESPONDED, // Response received
    QUERY_TARGET_NO_RESPONSE
} query_target_state_t;

typedef struct
{
    query_target_type_t type;
    query_target_state_t state;
    nw_addr_t *addr;
    nw_querydata_t data;
    unsigned int ping_time;
    unsigned int query_time;
    unsigned int query_attempts;
    boolean printed;
} query_target_t;

static boolean registered_with_master = false;
static boolean got_master_response = false;

static nw_context_t *query_context;
static query_target_t *targets;
static int num_targets;

static boolean query_loop_running = false;
static boolean printed_header = false;
static int last_query_time = 0;

// static char *securedemo_start_message = NULL;

// Resolve the master server address.

nw_addr_t *NW_Query_ResolveMaster(nw_context_t *context)
{
    nw_addr_t *addr;

    addr = NW_ResolveAddress(context, MASTER_SERVER_ADDRESS);

    if (addr == NULL)
    {
        I_Printf(VB_WARNING,
                 "Warning: Failed to resolve address "
                 "for master server: %s",
                 MASTER_SERVER_ADDRESS);
    }

    return addr;
}

// Send a registration packet to the master server to register
// ourselves with the global list.

void NW_Query_AddToMaster(nw_addr_t *master_addr)
{
    nw_packet_t *packet;

    packet = NW_NewPacket(10);
    NW_WriteInt16(packet, NW_MASTER_PACKET_TYPE_ADD);
    NW_SendPacket(master_addr, packet);
    NW_FreePacket(packet);
}

// Process a packet received from the master server.

void NW_Query_AddResponse(nw_packet_t *packet)
{
    unsigned int result;

    if (!NW_ReadInt16(packet, &result))
    {
        return;
    }

    if (result != 0)
    {
        // Only show the message once.

        if (!registered_with_master)
        {
            I_Printf(VB_INFO, "Registered with master server at %s",
                     MASTER_SERVER_ADDRESS);
            registered_with_master = true;
        }
    }
    else
    {
        // Always show rejections.

        I_Printf(VB_WARNING, "Failed to register with master server at %s",
                 MASTER_SERVER_ADDRESS);
    }

    got_master_response = true;
}

boolean NW_Query_CheckAddedToMaster(boolean *result)
{
    // Got response from master yet?

    if (!got_master_response)
    {
        return false;
    }

    *result = registered_with_master;
    return true;
}

// Send a query to the master server.

static void NW_Query_SendMasterQuery(nw_addr_t *addr)
{
    nw_packet_t *packet;

    packet = NW_NewPacket(4);
    NW_WriteInt16(packet, NW_MASTER_PACKET_TYPE_QUERY);
    NW_SendPacket(addr, packet);
    NW_FreePacket(packet);

    // We also send a NAT_HOLE_PUNCH_ALL packet so that servers behind
    // NAT gateways will open themselves up to us.
    packet = NW_NewPacket(4);
    NW_WriteInt16(packet, NW_MASTER_PACKET_TYPE_NAT_HOLE_PUNCH_ALL);
    NW_SendPacket(addr, packet);
    NW_FreePacket(packet);
}

// Send a hole punch request to the master server for the server at the
// given address.
void NW_RequestHolePunch(nw_context_t *context, nw_addr_t *addr)
{
    nw_addr_t *master_addr;
    nw_packet_t *packet;

    master_addr = NW_Query_ResolveMaster(context);
    if (master_addr == NULL)
    {
        return;
    }

    packet = NW_NewPacket(32);
    NW_WriteInt16(packet, NW_MASTER_PACKET_TYPE_NAT_HOLE_PUNCH);
    NW_WriteString(packet, NW_AddrToString(addr));
    NW_SendPacket(master_addr, packet);

    NW_FreePacket(packet);
    NW_ReleaseAddress(master_addr);
}

// Given the specified address, find the target associated.  If no
// target is found, and 'create' is true, a new target is created.

static query_target_t *GetTargetForAddr(nw_addr_t *addr, boolean create)
{
    query_target_t *target;
    int i;

    for (i = 0; i < num_targets; ++i)
    {
        if (targets[i].addr == addr)
        {
            return &targets[i];
        }
    }

    if (!create)
    {
        return NULL;
    }

    targets = I_Realloc(targets, sizeof(query_target_t) * (num_targets + 1));

    target = &targets[num_targets];
    target->type = QUERY_TARGET_SERVER;
    target->state = QUERY_TARGET_QUEUED;
    target->printed = false;
    target->query_attempts = 0;
    target->addr = addr;
    NW_ReferenceAddress(addr);
    ++num_targets;

    return target;
}

static void FreeTargets(void)
{
    int i;

    for (i = 0; i < num_targets; ++i)
    {
        NW_ReleaseAddress(targets[i].addr);
    }
    free(targets);
    targets = NULL;
    num_targets = 0;
}

// Transmit a query packet

static void NW_Query_SendQuery(nw_addr_t *addr)
{
    nw_packet_t *request;

    request = NW_NewPacket(10);
    NW_WriteInt16(request, NW_PACKET_TYPE_QUERY);

    if (addr == NULL)
    {
        NW_SendBroadcast(query_context, request);
    }
    else
    {
        NW_SendPacket(addr, request);
    }

    NW_FreePacket(request);
}

static void NW_Query_ParseResponse(nw_addr_t *addr, nw_packet_t *packet,
                                    nw_query_callback_t callback,
                                    void *user_data)
{
    unsigned int packet_type;
    nw_querydata_t querydata;
    query_target_t *target;

    // Read the header

    if (!NW_ReadInt16(packet, &packet_type)
        || packet_type != NW_PACKET_TYPE_QUERY_RESPONSE)
    {
        return;
    }

    // Read query data

    if (!NW_ReadQueryData(packet, &querydata))
    {
        return;
    }

    // Find the target that responded.

    target = GetTargetForAddr(addr, false);

    // If the target is not found, it may be because we are doing
    // a LAN broadcast search, in which case we need to create a
    // target for the new responder.

    if (target == NULL)
    {
        query_target_t *broadcast_target;

        broadcast_target = GetTargetForAddr(NULL, false);

        // Not in broadcast mode, unexpected response that came out
        // of nowhere. Ignore.

        if (broadcast_target == NULL
            || broadcast_target->state != QUERY_TARGET_QUERIED)
        {
            return;
        }

        // Create new target.

        target = GetTargetForAddr(addr, true);
        broadcast_target = GetTargetForAddr(NULL, false);
        target->state = QUERY_TARGET_QUERIED;
        target->query_time =
            broadcast_target ? broadcast_target->query_time : 0;
    }

    if (target->state != QUERY_TARGET_RESPONDED)
    {
        target->state = QUERY_TARGET_RESPONDED;
        memcpy(&target->data, &querydata, sizeof(nw_querydata_t));

        // Calculate RTT.

        target->ping_time = I_GetTimeMS() - target->query_time;

        // Invoke callback to signal that we have a new address.

        callback(addr, &target->data, target->ping_time, user_data);
    }
}

// Parse a response packet from the master server.

static void NW_Query_ParseMasterResponse(nw_addr_t *master_addr,
                                          nw_packet_t *packet)
{
    unsigned int packet_type;
    query_target_t *target;
    char *addr_str;
    nw_addr_t *addr;

    // Read the header.  We are only interested in query responses.

    if (!NW_ReadInt16(packet, &packet_type)
        || packet_type != NW_MASTER_PACKET_TYPE_QUERY_RESPONSE)
    {
        return;
    }

    // Read a list of strings containing the addresses of servers
    // that the master knows about.

    for (;;)
    {
        addr_str = NW_ReadString(packet);

        if (addr_str == NULL)
        {
            break;
        }

        // Resolve address and add to targets list if it is not already
        // there.

        addr = NW_ResolveAddress(query_context, addr_str);
        if (addr != NULL)
        {
            GetTargetForAddr(addr, true);
            NW_ReleaseAddress(addr);
        }
    }

    // Mark the master as having responded.

    target = GetTargetForAddr(master_addr, true);
    target->state = QUERY_TARGET_RESPONDED;
}

static void NW_Query_ParsePacket(nw_addr_t *addr, nw_packet_t *packet,
                                  nw_query_callback_t callback,
                                  void *user_data)
{
    query_target_t *target;

    // This might be the master server responding.

    target = GetTargetForAddr(addr, false);

    if (target != NULL && target->type == QUERY_TARGET_MASTER)
    {
        NW_Query_ParseMasterResponse(addr, packet);
    }
    else
    {
        NW_Query_ParseResponse(addr, packet, callback, user_data);
    }
}

static void NW_Query_GetResponse(nw_query_callback_t callback,
                                  void *user_data)
{
    nw_addr_t *addr;
    nw_packet_t *packet;

    if (NW_RecvPacket(query_context, &addr, &packet))
    {
        NW_Query_ParsePacket(addr, packet, callback, user_data);
        NW_ReleaseAddress(addr);
        NW_FreePacket(packet);
    }
}

// Find a target we have not yet queried and send a query.

static void SendOneQuery(void)
{
    unsigned int now;
    unsigned int i;

    now = I_GetTimeMS();

    // Rate limit - only send one query every 50ms.

    if (now - last_query_time < 50)
    {
        return;
    }

    for (i = 0; i < num_targets; ++i)
    {
        // Not queried yet?
        // Or last query timed out without a response?

        if (targets[i].state == QUERY_TARGET_QUEUED
            || (targets[i].state == QUERY_TARGET_QUERIED
                && now - targets[i].query_time > QUERY_TIMEOUT_SECS * 1000))
        {
            break;
        }
    }

    if (i >= num_targets)
    {
        return;
    }

    // Found a target to query.  Send a query; how to do this depends on
    // the target type.

    switch (targets[i].type)
    {
        case QUERY_TARGET_SERVER:
            NW_Query_SendQuery(targets[i].addr);
            break;

        case QUERY_TARGET_BROADCAST:
            NW_Query_SendQuery(NULL);
            break;

        case QUERY_TARGET_MASTER:
            NW_Query_SendMasterQuery(targets[i].addr);
            break;
    }

    // printf("Queried %s\n", NW_AddrToString(targets[i].addr));
    targets[i].state = QUERY_TARGET_QUERIED;
    targets[i].query_time = now;
    ++targets[i].query_attempts;

    last_query_time = now;
}

// Time out servers that have been queried and not responded.

static void CheckTargetTimeouts(void)
{
    unsigned int i;
    unsigned int now;

    now = I_GetTimeMS();

    for (i = 0; i < num_targets; ++i)
    {
        /*
        printf("target %i: state %i, queries %i, query time %i\n",
               i, targets[i].state, targets[i].query_attempts,
               now - targets[i].query_time);
        */

        // We declare a target to be "no response" when we've sent
        // multiple query packets to it (QUERY_MAX_ATTEMPTS) and
        // received no response to any of them.

        if (targets[i].state == QUERY_TARGET_QUERIED
            && targets[i].query_attempts >= QUERY_MAX_ATTEMPTS
            && now - targets[i].query_time > QUERY_TIMEOUT_SECS * 1000)
        {
            targets[i].state = QUERY_TARGET_NO_RESPONSE;

            if (targets[i].type == QUERY_TARGET_MASTER)
            {
                I_Printf(VB_WARNING, "NW_MasterQuery: no response "
                                     "from master server.");
            }
        }
    }
}

// If all targets have responded or timed out, returns true.

static boolean AllTargetsDone(void)
{
    unsigned int i;

    for (i = 0; i < num_targets; ++i)
    {
        if (targets[i].state != QUERY_TARGET_RESPONDED
            && targets[i].state != QUERY_TARGET_NO_RESPONSE)
        {
            return false;
        }
    }

    return true;
}

// Polling function, invoked periodically to send queries and
// interpret new responses received from remote servers.
// Returns zero when the query sequence has completed and all targets
// have returned responses or timed out.

int NW_Query_Poll(nw_query_callback_t callback, void *user_data)
{
    CheckTargetTimeouts();

    // Send a query.  This will only send a single query at once.

    SendOneQuery();

    // Check for a response

    NW_Query_GetResponse(callback, user_data);

    return !AllTargetsDone();
}

// Stop the query loop

static void NW_Query_ExitLoop(void)
{
    query_loop_running = false;
}

// Loop waiting for responses.
// The specified callback is invoked when a new server responds.

static void NW_Query_QueryLoop(nw_query_callback_t callback, void *user_data)
{
    query_loop_running = true;

    while (query_loop_running && NW_Query_Poll(callback, user_data))
    {
        // Don't thrash the CPU

        I_Sleep(1);
    }
}

void NW_Query_Init(void)
{
    if (query_context == NULL)
    {
        query_context = NW_NewContext();
        NW_AddModule(query_context, &nw_sdl_module);
        nw_sdl_module.InitClient();
    }

    free(targets);
    targets = NULL;
    num_targets = 0;

    printed_header = false;
}

// Callback that exits the query loop when the first server is found.

static void NW_Query_ExitCallback(nw_addr_t *addr, nw_querydata_t *data,
                                   unsigned int ping_time, void *user_data)
{
    NW_Query_ExitLoop();
}

// Search the targets list and find a target that has responded.
// If none have responded, returns NULL.

static query_target_t *FindFirstResponder(void)
{
    unsigned int i;

    for (i = 0; i < num_targets; ++i)
    {
        if (targets[i].type == QUERY_TARGET_SERVER
            && targets[i].state == QUERY_TARGET_RESPONDED)
        {
            return &targets[i];
        }
    }

    return NULL;
}

// Return a count of the number of responses.

static int GetNumResponses(void)
{
    unsigned int i;
    int result;

    result = 0;

    for (i = 0; i < num_targets; ++i)
    {
        if (targets[i].type == QUERY_TARGET_SERVER
            && targets[i].state == QUERY_TARGET_RESPONDED)
        {
            ++result;
        }
    }

    return result;
}

int NW_StartLANQuery(void)
{
    query_target_t *target;

    NW_Query_Init();

    // Add a broadcast target to the list.

    target = GetTargetForAddr(NULL, true);
    target->type = QUERY_TARGET_BROADCAST;

    return 1;
}

int NW_StartMasterQuery(void)
{
    nw_addr_t *master;
    query_target_t *target;

    NW_Query_Init();

    // Resolve master address and add to targets list.

    master = NW_Query_ResolveMaster(query_context);

    if (master == NULL)
    {
        return 0;
    }

    target = GetTargetForAddr(master, true);
    target->type = QUERY_TARGET_MASTER;
    NW_ReleaseAddress(master);

    return 1;
}

// -----------------------------------------------------------------------

static void formatted_printf(int wide, const char *s, ...) PRINTF_ATTR(2, 3);

static void formatted_printf(int wide, const char *s, ...)
{
    va_list args;
    int i;

    va_start(args, s);
    i = vprintf(s, args);
    va_end(args);

    while (i < wide)
    {
        putchar(' ');
        ++i;
    }
}

static const char *GameDescription(GameMode_t mode, GameMission_t mission)
{
    switch (mission)
    {
        case doom:
            if (mode == shareware)
            {
                return "swdoom";
            }
            else if (mode == registered)
            {
                return "regdoom";
            }
            else if (mode == retail)
            {
                return "ultdoom";
            }
            else
            {
                return "doom";
            }
        case doom2:
            return "doom2";
        case pack_tnt:
            return "tnt";
        case pack_plut:
            return "plutonia";
        case pack_chex:
            return "chex";
        case pack_hacx:
            return "hacx";
        default:
            return "?";
    }
}

static void PrintHeader(void)
{
    int i;

    putchar('\n');
    formatted_printf(5, "Ping");
    formatted_printf(18, "Address");
    formatted_printf(8, "Players");
    puts("Description");

    for (i = 0; i < 70; ++i)
    {
        putchar('=');
    }
    putchar('\n');
}

// Callback function that just prints information in a table.

static void NW_QueryPrintCallback(nw_addr_t *addr, nw_querydata_t *data,
                                   unsigned int ping_time, void *user_data)
{
    // If this is the first server, print the header.

    if (!printed_header)
    {
        PrintHeader();
        printed_header = true;
    }

    formatted_printf(5, "%4i", ping_time);
    formatted_printf(22, "%s", NW_AddrToString(addr));
    formatted_printf(4, "%i/%i ", data->num_players, data->max_players);

    if (data->gamemode != indetermined)
    {
        printf("(%s) ", GameDescription(data->gamemode, data->gamemission));
    }

    if (data->server_state)
    {
        printf("(game running) ");
    }

    printf("%s\n", data->description);
}

void NW_LANQuery(void)
{
    if (NW_StartLANQuery())
    {
        I_Printf(VB_INFO, "Searching for servers on local LAN ...");

        NW_Query_QueryLoop(NW_QueryPrintCallback, NULL);

        I_Printf(VB_INFO, "%i server(s) found.", GetNumResponses());
        FreeTargets();
    }
}

void NW_MasterQuery(void)
{
    if (NW_StartMasterQuery())
    {
        I_Printf(VB_INFO, "Searching for servers on Internet ...");

        NW_Query_QueryLoop(NW_QueryPrintCallback, NULL);

        I_Printf(VB_INFO, "%i server(s) found.", GetNumResponses());
        FreeTargets();
    }
}

void NW_QueryAddress(const char *addr_str)
{
    nw_addr_t *addr;
    query_target_t *target;

    NW_Query_Init();

    addr = NW_ResolveAddress(query_context, addr_str);

    if (addr == NULL)
    {
        I_Error("Host '%s' not found!", addr_str);
    }

    // Add the address to the list of targets.

    target = GetTargetForAddr(addr, true);

    I_Printf(VB_INFO, "Querying '%s'...", addr_str);

    // Run query loop.

    NW_Query_QueryLoop(NW_Query_ExitCallback, NULL);

    // Check if the target responded.

    if (target->state == QUERY_TARGET_RESPONDED)
    {
        NW_QueryPrintCallback(addr, &target->data, target->ping_time, NULL);
        NW_ReleaseAddress(addr);
        FreeTargets();
    }
    else
    {
        I_Error("No response from '%s'", addr_str);
    }
}

nw_addr_t *NW_FindLANServer(void)
{
    query_target_t *target;
    query_target_t *responder;
    nw_addr_t *result;

    NW_Query_Init();

    // Add a broadcast target to the list.

    target = GetTargetForAddr(NULL, true);
    target->type = QUERY_TARGET_BROADCAST;

    // Run the query loop, and stop at the first target found.

    NW_Query_QueryLoop(NW_Query_ExitCallback, NULL);

    responder = FindFirstResponder();

    if (responder != NULL)
    {
        result = responder->addr;
        NW_ReferenceAddress(result);
    }
    else
    {
        result = NULL;
    }

    FreeTargets();
    return result;
}

// Block until a packet of the given type is received from the given
// address.
/*
static nw_packet_t *BlockForPacket(nw_addr_t *addr, unsigned int packet_type,
                                    unsigned int timeout_ms)
{
    nw_packet_t *packet;
    nw_addr_t *packet_src;
    unsigned int read_packet_type;
    unsigned int start_time;

    start_time = I_GetTimeMS();

    while (I_GetTimeMS() < start_time + timeout_ms)
    {
        if (!NW_RecvPacket(query_context, &packet_src, &packet))
        {
            I_Sleep(20);
            continue;
        }

        // Caller doesn't need additional reference.
        NW_ReleaseAddress(packet_src);

        if (packet_src == addr
         && NW_ReadInt16(packet, &read_packet_type)
         && packet_type == read_packet_type)
        {
            return packet;
        }

        NW_FreePacket(packet);
    }

    // Timeout - no response.

    return NULL;
}

// Query master server for secure demo start seed value.

boolean NW_StartSecureDemo(prng_seed_t seed)
{
    nw_packet_t *request, *response;
    nw_addr_t *master_addr;
    char *signature;
    boolean result;

    NW_Query_Init();
    master_addr = NW_Query_ResolveMaster(query_context);

    // Send request packet to master server.

    request = NW_NewPacket(10);
    NW_WriteInt16(request, NW_MASTER_PACKET_TYPE_SIGN_START);
    NW_SendPacket(master_addr, request);
    NW_FreePacket(request);

    // Block for response and read contents.
    // The signed start message will be saved for later.

    response = BlockForPacket(master_addr,
                              NW_MASTER_PACKET_TYPE_SIGN_START_RESPONSE,
                              SIGNATURE_TIMEOUT_SECS * 1000);

    result = false;

    if (response != NULL)
    {
        if (NW_ReadPRNGSeed(response, seed))
        {
            signature = NW_ReadString(response);

            if (signature != NULL)
            {
                securedemo_start_message = M_StringDuplicate(signature);
                result = true;
            }
        }

        NW_FreePacket(response);
    }

    return result;
}

// Query master server for secure demo end signature.

char *NW_EndSecureDemo(sha1_digest_t demo_hash)
{
    nw_packet_t *request, *response;
    nw_addr_t *master_addr;
    char *signature;

    master_addr = NW_Query_ResolveMaster(query_context);

    // Construct end request and send to master server.

    request = NW_NewPacket(10);
    NW_WriteInt16(request, NW_MASTER_PACKET_TYPE_SIGN_END);
    NW_WriteSHA1Sum(request, demo_hash);
    NW_WriteString(request, securedemo_start_message);
    NW_SendPacket(master_addr, request);
    NW_FreePacket(request);

    // Block for response. The response packet simply contains a string
    // with the ASCII signature.

    response = BlockForPacket(master_addr,
                              NW_MASTER_PACKET_TYPE_SIGN_END_RESPONSE,
                              SIGNATURE_TIMEOUT_SECS * 1000);

    if (response == NULL)
    {
        return NULL;
    }

    signature = NW_ReadString(response);

    NW_FreePacket(response);

    return signature;
}
*/
