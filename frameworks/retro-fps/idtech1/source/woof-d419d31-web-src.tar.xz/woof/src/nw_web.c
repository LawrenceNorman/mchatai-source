//
// Web (Emscripten) build: single-player only. Stands in for nw_sdl.c, which
// needs SDL3_net and UDP sockets that a browser page cannot open.
//

#include "nw_sdl.h"

static boolean NW_Web_InitClient(void) { return false; }
static boolean NW_Web_InitServer(void) { return false; }
static void NW_Web_SendPacket(nw_addr_t *addr, nw_packet_t *packet) {}
static boolean NW_Web_RecvPacket(nw_addr_t **addr, nw_packet_t **packet) { return false; }

static void NW_Web_AddrToString(nw_addr_t *addr, char *buffer, int buffer_len)
{
    if (buffer_len > 0)
    {
        buffer[0] = '\0';
    }
}

static void NW_Web_FreeAddress(nw_addr_t *addr) {}
static nw_addr_t *NW_Web_ResolveAddress(const char *addr) { return NULL; }
static void NW_Web_Shutdown(void) {}

nw_module_t nw_sdl_module =
{
    NW_Web_InitClient,
    NW_Web_InitServer,
    NW_Web_SendPacket,
    NW_Web_RecvPacket,
    NW_Web_AddrToString,
    NW_Web_FreeAddress,
    NW_Web_ResolveAddress,
    NW_Web_Shutdown,
};
