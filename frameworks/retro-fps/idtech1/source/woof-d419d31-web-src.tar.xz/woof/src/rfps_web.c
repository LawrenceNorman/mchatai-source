//
// Copyright(C) 2026 mChatAI
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//      The small interface the retro-fps web page calls: pause, volumes,
//      difficulty / restart, and a snapshot of the player's state for the
//      page's overlay and tests. Built only for Emscripten.
//

#include <stdio.h>

#include <emscripten.h>

#include "d_player.h"
#include "doomdef.h"
#include "doomstat.h"
#include "g_game.h"
#include "m_fixed.h"
#include "p_mobj.h"
#include "s_sound.h"

void RFPS_WebFrame(void);

static int want_paused;
static int music_on = 1;

// Called once per browser frame, before the tics run. The page owns pausing
// (its overlay), so the engine's own pause bit follows want_paused; music the
// player switched off stays paused, even after a level change restarts it.
void RFPS_WebFrame(void)
{
    if (gamestate == GS_LEVEL)
    {
        if (want_paused && !(paused & 1))
        {
            paused |= 1;
            S_PauseSound();
            S_PauseMusic();
        }
        else if (!want_paused && (paused & 1))
        {
            paused &= ~1;
            S_ResumeSound();
            if (music_on)
            {
                S_ResumeMusic();
            }
        }
    }

    if (!music_on)
    {
        S_PauseMusic();
    }
}

EMSCRIPTEN_KEEPALIVE void rfps_pause(int on)
{
    want_paused = !!on;
}

// Volumes are 0..15; a negative value leaves that one unchanged. Music at 0
// is paused rather than played silently, so it costs nothing.
EMSCRIPTEN_KEEPALIVE void rfps_set_volume(int sfx, int music)
{
    if (sfx >= 0)
    {
        S_SetSfxVolume(sfx > 15 ? 15 : sfx);
    }
    if (music >= 0)
    {
        music_on = music > 0;
        S_SetMusicVolume(music > 15 ? 15 : music);
        if (music_on && !paused)
        {
            S_ResumeMusic();
        }
    }
}

// skill 1..5 as on the command line (0 keeps the current one); map 0 keeps
// the current map. Starts that map fresh, as a new game does.
EMSCRIPTEN_KEEPALIVE void rfps_new_game(int skill, int map)
{
    if (skill < 1 || skill > 5)
    {
        skill = gameskill + 1;
    }
    if (map < 1)
    {
        map = gamemap > 0 ? gamemap : 1;
    }
    G_DeferedInitNew((skill_t)(skill - 1), 1, map);
}

EMSCRIPTEN_KEEPALIVE const char *rfps_state(void)
{
    static char buf[640];
    const player_t *p = &players[consoleplayer];
    const mobj_t *mo = p->mo;

    snprintf(buf, sizeof(buf),
             "{\"gamestate\":%d,\"map\":%d,\"skill\":%d,\"paused\":%d,"
             "\"menu\":%d,\"health\":%d,\"armor\":%d,\"dead\":%d,"
             "\"weapon\":%d,\"ammo\":[%d,%d,%d,%d],\"kills\":%d,"
             "\"totalkills\":%d,\"items\":%d,\"totalitems\":%d,"
             "\"secrets\":%d,\"totalsecrets\":%d,\"leveltime\":%d,"
             "\"angle\":%u,\"x\":%d,\"y\":%d,\"music\":%d,\"sfx\":%d}",
             (int)gamestate, gamemap, (int)gameskill + 1, paused,
             (int)menuactive, p->health, p->armorpoints,
             p->playerstate == PST_DEAD, (int)p->readyweapon, p->ammo[0],
             p->ammo[1], p->ammo[2], p->ammo[3], p->killcount, totalkills,
             p->itemcount, totalitems, p->secretcount, totalsecret,
             leveltime, mo ? (unsigned)mo->angle : 0u,
             mo ? mo->x >> FRACBITS : 0, mo ? mo->y >> FRACBITS : 0,
             music_on ? snd_MusicVolume : 0, snd_SfxVolume);
    return buf;
}
